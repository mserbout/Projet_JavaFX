package esalaf.projet11;

public class GetData {
    public static Integer numbers;
    public static String username;


}
